import React, { Component } from 'react';

import './common.css';



function Footer() 
{
    return (<div className='footer'>
                <center> <h1>Footer</h1></center>
            </div>);
}
export default Footer;


// class Footer extends Component {
//     render() 
//     { 
//         debugger;
//         console.log("Footer Render is getting called..")
//         return (<div className='footer'>
//                    <center> <h1>Footer</h1></center>
//                 </div>);
//     }
// }
// export default Footer;