function NotFound() 
{
    return (<>  
                <br/><br/><br/><br/><br/><br/>
                <h1>
                    Page you are looking for does not exist!
                </h1>
                <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
            </>);
}

export default NotFound;