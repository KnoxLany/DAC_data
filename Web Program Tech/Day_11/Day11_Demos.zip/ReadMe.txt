1. node <programname.js> 
-will run the node js code written by you

2. npm init 
- create package .json file by asking you certain answers

(Instead of this kindle use)

3. npm init --yes 
(This will create package.json file 
 with default values.. which you can change 
 later)

 4. npm i <package Name> taken from npmjs.com>
- will install the package & it's dependencies inside node_modules folder

5. npm install
- this will download all dependencies by reading package.json file

package.lock.json contains actual path from where packages can be donwloaded..

Documentation Link:
https://nodejs.org/dist/latest-v18.x/docs/api/



