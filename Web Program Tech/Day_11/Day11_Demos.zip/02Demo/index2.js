// console.log(document);
// window.alert("hi");
var counter = 0;

setInterval(() => 
{
    counter = counter + 1;
    console.log(counter)    
}, 500);