// var F1 = ()=>{console.log("hi")};
// F1 = (x)=>{console.log("hi" + x)};
// F1();
// console.log(F1);
