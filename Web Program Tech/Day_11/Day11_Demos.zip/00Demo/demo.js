// console.log("Hi Hello");

// var v = 100;
// console.log(typeof(v));

// v = "abcd";
// console.log(typeof(v));

// v = true;
// console.log(typeof(v));

// v = null;
// console.log(typeof(v));

// v = undefined;
// console.log(typeof(v));

// if(10>2)
// {
//     console.log("10 > 2")
// }
// else
// {
//     console.log("miracle");
// }

// var i = 0;
// while(true)
// {
//     i = i + 1;
//     console.log(i);
//     if(i==5)
//     {
//         break;
//     }
// }

// var i = 0;
// do 
// {
//     i = i + 1;
//     console.log(i);
//     if(i==5)
//     {
//         break;
//     }
// }while(true)

// var v =2;
// switch (v) {
//     case 1:
//         console.log("One");
//         break;
//     case 2:
//         console.log("Two");
//         break;
//     default:
//         console.log("Something else.")
//         break;
// }

//--------------------------------------------------

