function Profile() {
    return ( 
        <h1>This is safe and secure profile page!</h1>
     );
}

export default Profile;