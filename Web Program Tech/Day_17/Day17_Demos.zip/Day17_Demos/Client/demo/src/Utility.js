function F1()
{
    console.log("This is F1");
}

function F2()
{
    console.log("This is F2");
}

function F3()
{
    console.log("This is F3");
}

export {F1, F2, F3}