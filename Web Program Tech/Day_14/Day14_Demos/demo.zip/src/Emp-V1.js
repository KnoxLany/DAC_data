// import React, { Component } from 'react';

// class Emp extends Component 
// {
    
//     state={EName : "Satish"}

//     DoSomething=()=>{
//         console.log("button click code called..")
//         //debugger;
//         //this.state.EName = "XYZ";
//         this.setState({EName : "XYZ"});
//     }

//     render() {
//         //debugger;
//         console.log("render called...")
//         return (<>
//                     <h1>Emp detail</h1>
//                     <h2>Hi {this.state.EName}</h2>
//                     <button onClick={this.DoSomething}>
//                         Click Me
//                     </button>
//                 </>); 

//         // return <React.Fragment>
//         //             <h1>Emp detail</h1>
//         //             <h2>Hi Hello</h2>
//         //         </React.Fragment>; 


//         // return (<>
//         //             <h1>Emp detail</h1>
//         //             <h2>Hi Hello</h2>
//         //         </>); 

//         // return (<div>
//         //             <h1>Emp detail</h1>
//         //             <h2>Hi Hello</h2>
//         //         </div>);
//     }
// }
 
// export default Emp;