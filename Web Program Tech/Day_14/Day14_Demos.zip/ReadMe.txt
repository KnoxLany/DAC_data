Create / Open any folder:
npm i create-react-app

In the same folder
npx create-react-app demo

Open demo folder in VScode & Start coding