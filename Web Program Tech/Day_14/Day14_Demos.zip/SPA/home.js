//Sameer
//ES6: 2015
class Home    //This is like Class Component In React
{
    render()
    {
        return  `<br><br><br>
                    <h1>
                    Welcome Home
                    </h1>
                 <br><br><br>`;
    }
}
// function Home()   //This is Function Component in React
// {
//     return  `<br><br><br>
//                 <h1>
//                 Welcome Home
//                 </h1>
//             <br><br><br>`;
// }