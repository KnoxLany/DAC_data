//Amit
function About()
{
    return `<br><br><br>
                <h1>
                About Us!
                </h1>
            <br><br><br>`;
}