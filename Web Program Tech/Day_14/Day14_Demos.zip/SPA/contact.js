//Rohan
function Contact()
{
   return            `<br><br><br>
                        <h1>
                        Contact Us Here!!
                        </h1>
                      <br><br><br>`
}