function NotFound()
{
    return `<br><br><br>
            <h1>
            No resource!
            </h1>
            <br><br><br>`;
}