
// function Home() 
// {
//   debugger;
//   return <h1>Hello React!</h1>;
// }

import { Component } from "react";

 
class Home extends Component
{
  render()
  {
    debugger;
    return <h1>Hello React!</h1>;
  }
}

export default Home;
